"""Command line entry point for static reproducibility checks."""

import argparse
import json
from pathlib import Path

from .initial_lr import audit
from .rotation import audit_rotation


def main():
    parser = argparse.ArgumentParser(description="Compare a paper with a documented Git snapshot.")
    parser.add_argument("--pdf", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--stage", required=True)
    parser.add_argument("--group", help="Optimizer group, e.g. pretrained weights")
    parser.add_argument("--check", choices=("initial-lr", "test-rotation"), default="initial-lr")
    parser.add_argument("--dataset", help="Dataset named in the paper for test-rotation")
    parser.add_argument("--domain", help="Identifier of the test domain")
    args = parser.parse_args()
    if not args.stage.strip():
        parser.error("--stage must contain a stage description")
    try:
        if args.check == "test-rotation":
            if not (args.dataset and args.dataset.strip() and args.domain and args.domain.strip()):
                parser.error("--check test-rotation requires --dataset and --domain")
            if args.group:
                parser.error("--group applies to the initial-lr check")
            result = audit_rotation(args.pdf, args.repo, args.commit, args.stage.strip(),
                                    args.dataset.strip(), args.domain.strip())
        else:
            result = audit(args.pdf, args.repo, args.commit, args.stage.strip(), args.group)
    except (OSError, ValueError, RuntimeError) as error:
        parser.error(str(error))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
